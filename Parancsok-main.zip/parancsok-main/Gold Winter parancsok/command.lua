RegisterCommand("discord", function()
msg("Discord linkért nyomj F8-at és jelöld ki majd CTRL+C utána böngészőn CTRL+V!")
msg("LINK: https://discord.gg/TZh4nPZ4PC")
end, false)

function msg(text)

TriggerEvent("chatMessage", "[Drip Moon Discord]", {255,0,0}, text)
end

RegisterCommand("törlés", function(source, args)
TriggerEvent('chat:clear')
msg("A chat törölve lett!")
end, false)

function msg(text)

TriggerEvent("chatMessage", "[Drip Moon Chat]", {255,0,0}, text)
end

RegisterCommand("halál", function()
SetEntityHealth(PlayerPedId(), 0)
msg("Meghaltál!")
end)

function msg(text)

TriggerEvent("chatMessage", "[Drip Moon Halál]", {255,0,0}, text)
end